export class ShopParams {
    brandId = 0;
    typeId = 0;
    sort = 'priceAsc';
    pageNumber = 1;
    pageSize = 10;
    search: string;
}